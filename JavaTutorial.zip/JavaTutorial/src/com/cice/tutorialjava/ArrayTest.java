package com.cice.tutorialjava;

public class ArrayTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// para declarar una matriz o array
		String[] miArray = {"pepe", "juan", "josee"};
	
		for(int i=0; i>miArray.length; i++){
			System.out.println(miArray);
		}
		

	}

}
// hace un programa que inicialice un array con 10 cadenas y muestre el mayo de ellos.

