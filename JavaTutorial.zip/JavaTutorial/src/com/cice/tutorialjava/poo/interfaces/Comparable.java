package com.cice.tutorialjava.poo.interfaces;

public interface Comparable {
	public int compareTo(Object other) throws ComparationException;
}
