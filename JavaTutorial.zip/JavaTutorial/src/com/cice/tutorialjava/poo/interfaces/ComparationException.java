package com.cice.tutorialjava.poo.interfaces;

public class ComparationException extends Exception {

	public ComparationException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
