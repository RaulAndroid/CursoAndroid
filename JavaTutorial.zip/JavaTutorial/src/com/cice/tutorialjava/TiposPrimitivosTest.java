package com.cice.tutorialjava;

public class TiposPrimitivosTest {

	public static void main(String[] args) { //Mienbro de la clase.
		// Tipos primitivos. 
		int x; // las variables en java termina en ; el = es un operador de asignación.
		x = 10; // a la izqquiera del = aparece la variable y a la derecha el valor que quiero asignar a la variable
		short s = 34;
		float f =  5.7f;
		double d = 98.7;
		boolean b= true;
		char c = 'r';
		String str = "luis";
		System.out.println("Valor de c:" + c); // más actua como concatenador. dentro de syso podemos mezclar valores constantes con valores variables.
		System.out.println("Valor de str:" + str);
		System.out.println("Valor de d:" + d);
		
	}

}
