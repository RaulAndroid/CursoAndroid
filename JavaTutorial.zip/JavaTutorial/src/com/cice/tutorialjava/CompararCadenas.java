package com.cice.tutorialjava;

public class CompararCadenas {

	public static void main (String[] args){
		String str1=new String("Luis");
		String str2=new String("Luis");
		System.out.println(str1.equals(str2));
		
	}
}
