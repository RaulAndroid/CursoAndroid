package com.cice.tutorialjava;



public class InstruccionesControlFlujo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Alternativa simple. Comentario simple.
		/* Comentario multilinea.
		 * */

	
		}
	}
	


